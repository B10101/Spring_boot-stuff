package bett.employee_post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import bett.employee_post.emp.Employee;
import bett.employee_post.emp.Employeecontroller;
import bett.employee_post.emp.Employeeservice;


@SpringBootTest
class EmployeePostApplicationTests {

    @InjectMocks
    private Employeecontroller employeeController;

    @Mock
    private Employeeservice employeeService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateEmployee() {
        // Arrange
        Employee mockEmployee = new Employee("12345", "John", "Doe", "john.doe@example.com", "Software Engineer");
        when(employeeService.addEmployee(any(Employee.class))).thenReturn(mockEmployee);

        // Act
        Employee newEmployee = new Employee("12345", "John", "Doe", "john.doe@example.com", "Software Engineer");
        ResponseEntity<Employee> response = employeeController.createEmployee(newEmployee);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(mockEmployee, response.getBody());
    }
}



